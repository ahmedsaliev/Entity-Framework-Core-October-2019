﻿namespace P03_FootballBetting.DatabaseConfiguration
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=OFAZ\SQLEXPRESS;Database=FootballBetting; Integrated Security=true";
    }
}