﻿namespace P03_FootballBetting.Enumarations
{
    public enum Prediction
    {
        Win = 1,
        Draw = 0,
        Lost = -1
    }
}